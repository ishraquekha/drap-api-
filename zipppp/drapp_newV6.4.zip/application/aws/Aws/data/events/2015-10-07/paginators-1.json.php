<?php
// This file was auto-generated from sdk-root/src/data/events/2015-10-07/paginators-1.json
return [ 'pagination' => [],];
