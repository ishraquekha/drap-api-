<?php
// This file was auto-generated from sdk-root/src/data/discovery/2015-11-01/paginators-1.json
return [ 'pagination' => [ 'DescribeContinuousExports' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'DescribeImportTasks' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], ],];
