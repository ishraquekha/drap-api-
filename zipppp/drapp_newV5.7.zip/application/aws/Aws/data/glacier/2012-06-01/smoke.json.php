<?php
// This file was auto-generated from sdk-root/src/data/glacier/2012-06-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListVaults', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'ListVaults', 'input' => [ 'accountId' => 'abcmnoxyz', ], 'errorExpectedFromService' => true, ], ],];
