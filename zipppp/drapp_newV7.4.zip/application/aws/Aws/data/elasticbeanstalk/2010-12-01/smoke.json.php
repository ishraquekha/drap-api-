<?php
// This file was auto-generated from sdk-root/src/data/elasticbeanstalk/2010-12-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListAvailableSolutionStacks', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeEnvironmentResources', 'input' => [ 'EnvironmentId' => 'fake_environment', ], 'errorExpectedFromService' => true, ], ],];
